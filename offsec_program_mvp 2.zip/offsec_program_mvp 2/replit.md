# Offensive Security Program MVP

## Overview

This project is an internal offensive security program management system built with FastAPI and SQLAlchemy. It provides a REST API for tracking penetration testing engagements, managing security findings, coordinating with blue teams, and organizing offensive security activities across program years.

The application serves as a backend service for security teams to manage the full lifecycle of penetration tests—from intake requests through execution to remediation tracking. It includes structured reporting capabilities and reusable asset/finding template libraries.

## Recent Changes

**November 19, 2025** - Enhanced for small team internal use:
- Fixed N+1 query bug in engagement listing (now uses joinedload for better performance)
- Added Finding Templates CRUD API (`/finding-templates`) for reusable vulnerability descriptions
- Implemented API key authentication with X-API-Key header (backward compatible with no-auth mode)
- Added CSV export endpoint (`/engagements/{id}/export/csv`) for findings
- Added Markdown export endpoint (`/engagements/{id}/export/markdown`) for complete reports
- Added API key regeneration endpoint for administrators

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture

**Framework**: FastAPI (Python)
- Chosen for its automatic API documentation, type validation via Pydantic, and async capabilities
- Provides built-in OpenAPI/Swagger UI for API exploration
- Dependency injection pattern used throughout for database sessions and authentication

**ORM Layer**: SQLAlchemy
- Declarative base pattern for model definitions
- Session factory pattern with explicit transaction control (autocommit=False, autoflush=False)
- All models inherit from a shared Base class defined in db.py

**API Structure**: RESTful with nested resources
- Top-level resources: users, intake requests, engagements, assets, finding templates
- Nested resources: findings live under engagements (`/engagements/{id}/findings`)
- Timeline events and comments attached to parent entities
- Special `/report` endpoint for structured report generation

**Authentication**: API key based
- X-API-Key header for authentication (automatically generated for new users)
- Fallback to first user for backward compatibility when no API key provided
- API key regeneration endpoint (`POST /users/{id}/regenerate-api-key`) for administrators
- User roles defined: red, blue, manager, admin
- Note: Password hashing not enforced in MVP—uses placeholder values

### Data Architecture

**Primary Entities**:
1. **ProgramYear** - Top-level organizational container for annual programs
2. **Engagement** - Core entity representing individual penetration tests
3. **Finding** - Vulnerabilities discovered during engagements
4. **Asset** - Reusable target inventory (hosts, apps, networks, cloud accounts)
5. **IntakeRequest** - Initial requests for testing that convert to engagements
6. **FindingTemplate** - Reusable vulnerability descriptions and remediation guidance
7. **TimelineEvent** - Audit trail of engagement activities
8. **Comment** - Collaboration notes on engagements or findings

**Data Relationships**:
- ProgramYear → many Engagements (one-to-many)
- Engagement → many Findings, Assets (via association), TimelineEvents, Comments (one-to-many)
- Finding → optional FindingTemplate reference, many linked Assets, many Comments (one-to-many/many-to-one)
- User → created Findings, IntakeRequests, TimelineEvents (one-to-many via created_by_id)

**Database Strategy**: 
- SQLite for local development (single file: `offsec_program.db`)
- Connection string centralized in db.py for easy migration to PostgreSQL
- Schema created via `Base.metadata.create_all()` on startup (production would use migrations)
- Uses check_same_thread=False for SQLite to allow cross-thread access

### Schema Validation

**Pydantic Models**: Separate schemas package with domain-specific modules
- Create schemas: Used for POST requests with required fields
- Update schemas: All fields optional for PATCH operations
- Out/Detail schemas: Control serialization with orm_mode=True
- Nested schemas: Detail views include related entities (e.g., EngagementDetail includes findings, assets, timeline)

**Validation Patterns**:
- Field constraints via Pydantic Field() with examples
- Enum-like string fields (e.g., severity: Info/Low/Medium/High/Critical)
- Optional fields default to None
- Datetime fields auto-populated by database defaults

### Special Features

**Report Generation**: 
- `/engagements/{id}/report` endpoint produces structured JSON
- Includes executive summary, finding statistics, detailed findings with affected assets
- Groups findings by severity with counts
- Designed to feed document generation tools (Word/PDF not implemented)

**CSV & Markdown Export**:
- `/engagements/{id}/export/csv` exports findings as CSV with all details
- `/engagements/{id}/export/markdown` exports complete report in Markdown format
- Useful for importing to spreadsheets, ticketing systems, or documentation

**Finding Template Library**:
- Full CRUD API at `/finding-templates/` for managing reusable vulnerability templates
- Templates include CWE IDs, MITRE ATT&CK techniques, standard descriptions, and remediation guidance
- Accelerates finding documentation by referencing templates when creating findings via template_id
- Filter templates by category for quick access

**Asset Catalog**:
- Centralized inventory independent of engagements
- Supports multiple asset types: Host, IP-Range, App, Domain, URL, Cloud-Account, OT-Device
- Assets can be linked to multiple findings and engagements
- Criticality and environment tagging for risk prioritization

**Timeline & Collaboration**:
- Timeline events provide audit trail of engagement activities
- Comments enable team collaboration on engagements and findings
- Both track creating user and timestamp

## External Dependencies

### Python Packages
- **fastapi**: Web framework for building the REST API
- **uvicorn**: ASGI server for running the FastAPI application
- **sqlalchemy**: ORM for database operations and model definitions
- **pydantic**: Data validation and serialization (version <2 specified for compatibility)

### Database
- **SQLite**: Default database engine (file-based: `offsec_program.db`)
- Designed for easy migration to PostgreSQL by changing connection string in db.py
- No external database server required for local development

### Authentication
- API key authentication (custom implementation)
- No external SSO or OAuth providers in MVP
- Future integration points: LDAP, SAML, OAuth2

### Third-Party Services
None currently integrated. Potential future integrations:
- Document generation services for Word/PDF reports
- Ticketing systems for remediation tracking (Jira, ServiceNow)
- SIEM/logging platforms for timeline event forwarding
- Vulnerability scanners for automated finding import
- MITRE ATT&CK framework API for technique validation